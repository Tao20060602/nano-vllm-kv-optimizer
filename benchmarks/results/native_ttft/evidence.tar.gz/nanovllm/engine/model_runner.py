import pickle
import torch
import torch.distributed as dist
from multiprocessing.synchronize import Event
from multiprocessing.shared_memory import SharedMemory

from nanovllm.config import Config
from nanovllm.engine.sequence import Sequence
from nanovllm.models.qwen3 import Qwen3ForCausalLM
from nanovllm.models.llama import LlamaForCausalLM
from nanovllm.layers.sampler import Sampler
from nanovllm.utils.context import set_context, get_context, reset_context
from nanovllm.utils.loader import load_model
from nanovllm.kvdb.timing import ModelStageTimer
from nanovllm.kvdb.store.gpu import GPUBlockStore
from nanovllm.kvdb.store.cpu import CPUBlockStore
from nanovllm.kvdb.coordinator import ContextDB


class ModelRunner:

    def __init__(self, config: Config, rank: int, event: Event | list[Event]):
        self.config = config
        hf_config = config.hf_config
        self.block_size = config.kvcache_block_size
        self.enforce_eager = config.enforce_eager
        self.world_size = config.tensor_parallel_size
        self.rank = rank
        self.event = event
        self.metrics = None
        self.last_cpu_store_error = None

        dist.init_process_group("nccl", "tcp://localhost:2333", world_size=self.world_size, rank=rank)
        torch.cuda.set_device(rank)
        default_dtype = torch.get_default_dtype()
        torch.set_default_dtype(hf_config.dtype)
        torch.set_default_device("cuda")
        if hf_config.model_type == "qwen3":
            self.model = Qwen3ForCausalLM(hf_config)
        elif hf_config.model_type == "llama":
            self.model = LlamaForCausalLM(hf_config)
        else:
            raise ValueError(f"Unsupported model_type: {hf_config.model_type}")
        load_model(self.model, config.model)
        self.sampler = Sampler()
        self.warmup_model()
        self.allocate_kv_cache()
        if not self.enforce_eager:
            self.capture_cudagraph()
        torch.set_default_device("cpu")
        torch.set_default_dtype(default_dtype)

        if self.world_size > 1:
            if rank == 0:
                self.shm = SharedMemory(name="nanovllm", create=True, size=2**20)
                dist.barrier()
            else:
                dist.barrier()
                self.shm = SharedMemory(name="nanovllm")
                self.loop()

    def exit(self):
        if self.world_size > 1:
            self.shm.close()
            dist.barrier()
            if self.rank == 0:
                self.shm.unlink()
        if not self.enforce_eager:
            del self.graphs, self.graph_pool
        torch.cuda.synchronize()
        dist.destroy_process_group()

    def loop(self):
        while True:
            method_name, args = self.read_shm()
            self.call(method_name, *args)
            if method_name == "exit":
                break

    def read_shm(self):
        assert self.world_size > 1 and self.rank > 0
        self.event.wait()
        n = int.from_bytes(self.shm.buf[0:4], "little")
        method_name, *args = pickle.loads(self.shm.buf[4:n+4])
        self.event.clear()
        return method_name, args

    def write_shm(self, method_name, *args):
        assert self.world_size > 1 and self.rank == 0
        data = pickle.dumps([method_name, *args])
        n = len(data)
        self.shm.buf[0:4] = n.to_bytes(4, "little")
        self.shm.buf[4:n+4] = data
        for event in self.event:
            event.set()

    def call(self, method_name, *args):
        if self.world_size > 1 and self.rank == 0:
            self.write_shm(method_name, *args)
        method = getattr(self, method_name, None)
        return method(*args)

    def warmup_model(self):
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        max_num_batched_tokens, max_model_len = self.config.max_num_batched_tokens, self.config.max_model_len
        seq_len = min(max_num_batched_tokens, max_model_len)
        num_seqs = min(max_num_batched_tokens // seq_len, self.config.max_num_seqs)
        seqs = [Sequence([0] * seq_len) for _ in range(num_seqs)]
        for seq in seqs:
            seq.num_scheduled_tokens = seq_len
        self.run(seqs, True)
        torch.cuda.empty_cache()

    def allocate_kv_cache(self):
        config = self.config
        hf_config = config.hf_config
        free, total = torch.cuda.mem_get_info()
        used = total - free
        peak = torch.cuda.memory_stats()["allocated_bytes.all.peak"]
        current = torch.cuda.memory_stats()["allocated_bytes.all.current"]
        num_kv_heads = hf_config.num_key_value_heads // self.world_size
        head_dim = getattr(hf_config, "head_dim", hf_config.hidden_size // hf_config.num_attention_heads)

        # ---- M11/M12 sparse: zero physical paged blocks, per-layer CPU history ----
        if config.enable_sparse_attention:
            config.num_kvcache_blocks = 0
            self.kv_cache = torch.empty(
                2, hf_config.num_hidden_layers, 0, self.block_size,
                num_kv_heads, head_dim)
            self.gpu_block_store = None
            self.cpu_block_store = None
            self.context_db = None
            if getattr(config, 'use_m12_runtime', False):
                from nanovllm.sparse.m12_runtime import M12Config, M12LayerRuntime
                prefill_adapter = None
                if config.sparse_prefill_attention_backend in ("flash_reuse", "operator"):
                    from nanovllm.sparse.segmented_prefill_adapter import SegmentedPrefillAdapter
                    prefill_adapter = SegmentedPrefillAdapter(
                        config.sparse_prefill_attention_backend, head_dim ** -0.5,
                        (hf_config.num_attention_heads, num_kv_heads, head_dim, hf_config.dtype),
                        config.sparse_operator_root)
                m12_cfg = M12Config(
                    block_size=config.sparse_retrieval_block_size,
                    r=config.sparse_num_representatives,
                    recent_tokens=config.sparse_recent_tokens,
                    sink_tokens=config.sparse_first_tokens or 64,
                    top_k_blocks=config.sparse_top_k,
                    prefill_top_k_blocks=config.sparse_prefill_top_k,
                    decode_top_k_blocks=config.sparse_decode_top_k,
                    dynamic_top_k=config.sparse_dynamic_top_k,
                    dynamic_top_k_mass=config.sparse_dynamic_top_k_mass,
                    max_model_len=config.max_model_len,
                    num_heads=hf_config.num_attention_heads,
                    num_kv_heads=num_kv_heads,
                    head_dim=head_dim,
                    dtype=hf_config.dtype,
                    scale=head_dim ** -0.5,
                    use_index_select=config.sparse_gather_index_select,
                    decode_kv_pipeline=config.sparse_decode_kv_pipeline,
                    selector_cuda_graph=config.sparse_selector_cuda_graph,
                    selector_static_mask=config.sparse_selector_static_mask,
                    check_finite_outputs=config.sparse_check_finite_outputs,
                    prefill_query_segments=config.sparse_prefill_query_segments,
                    prefill_attention_backend=config.sparse_prefill_attention_backend,
                    prefill_adapter=prefill_adapter,
                )
                layer_id = 0
                for module in self.model.modules():
                    if hasattr(module, "k_cache") and hasattr(module, "v_cache"):
                        module.layer_id = layer_id
                        module.k_cache = self.kv_cache[0, layer_id]
                        module.v_cache = self.kv_cache[1, layer_id]
                        module.sparse_rt = M12LayerRuntime(layer_id, m12_cfg)
                        layer_id += 1
                return
            from nanovllm.sparse.engine_runtime import SparseEngineConfig, SparseLayerRuntime
            sparse_cfg = SparseEngineConfig(
                selector=config.sparse_selector,
                rbs=config.sparse_retrieval_block_size,
                recent_tokens=config.sparse_recent_tokens,
                first_tokens=config.sparse_first_tokens,
                top_k=config.sparse_top_k,
                beta_raw=config.sparse_beta_raw,
                num_representatives=config.sparse_num_representatives,
                graph_degree=config.sparse_graph_degree,
                graph_l0=config.sparse_graph_l0,
                graph_max_scored=config.sparse_graph_max_scored_blocks,
                graph_projection_topk=config.sparse_graph_projection_topk,
                query_samples=config.sparse_query_samples,
                num_heads=hf_config.num_attention_heads,
                num_kv_heads=num_kv_heads,
                head_dim=head_dim,
                dtype=hf_config.dtype,
                scale=head_dim ** -0.5,
                max_model_len=config.max_model_len,
            )
            layer_id = 0
            for module in self.model.modules():
                if hasattr(module, "k_cache") and hasattr(module, "v_cache"):
                    module.layer_id = layer_id
                    module.k_cache = self.kv_cache[0, layer_id]
                    module.v_cache = self.kv_cache[1, layer_id]
                    module.sparse_rt = SparseLayerRuntime(layer_id, sparse_cfg)
                    layer_id += 1
            return

        block_bytes = 2 * hf_config.num_hidden_layers * self.block_size * num_kv_heads * head_dim * hf_config.dtype.itemsize
        config.num_kvcache_blocks = int(total * config.gpu_memory_utilization - used - peak + current) // block_bytes
        assert config.num_kvcache_blocks > 0
        self.kv_cache = torch.empty(2, hf_config.num_hidden_layers, config.num_kvcache_blocks, self.block_size, num_kv_heads, head_dim)
        self.gpu_block_store = None
        self.cpu_block_store = None
        self.context_db = None
        if config.enable_reusable_cache:
            self.gpu_block_store = GPUBlockStore(self.kv_cache, config.cache_fingerprint)
        if config.enable_cpu_cache:
            self.cpu_block_store = CPUBlockStore(
                config.cache_fingerprint,
                capacity_bytes=config.cpu_cache_capacity_bytes,
                pinned=config.cpu_cache_pinned,
            )
            self.context_db = ContextDB(self.cpu_block_store)
        layer_id = 0
        for module in self.model.modules():
            if hasattr(module, "k_cache") and hasattr(module, "v_cache"):
                # Record the logical layer id so the attention tracer can
                # target one specific layer.
                module.layer_id = layer_id
                if self.gpu_block_store is None:
                    module.k_cache = self.kv_cache[0, layer_id]
                    module.v_cache = self.kv_cache[1, layer_id]
                else:
                    module.k_cache, module.v_cache = self.gpu_block_store.layer_cache(layer_id)
                layer_id += 1

    # -- M9 real-model attention trace (opt-in, one-shot) -------------------
    def arm_attention_trace(self, layer_id: int, query_samples: int = 0):
        from nanovllm.utils.trace import get_tracer
        get_tracer().arm(int(layer_id), query_samples=int(query_samples))

    def retrieve_attention_trace(self):
        from nanovllm.utils.trace import get_tracer
        return get_tracer().retrieve()

    def clear_attention_trace(self):
        from nanovllm.utils.trace import get_tracer
        get_tracer().clear()

    # -- M11 sparse control -------------------------------------------------
    def m12_reset(self):
        """Clear per-sequence M12 state while retaining allocated KV buffers."""
        if not self.config.use_m12_runtime:
            return
        for module in self.model.modules():
            rt = getattr(module, "sparse_rt", None)
            if rt is not None and hasattr(rt, "prefill_first"):
                rt.reset()

    def sparse_reset(self):
        from nanovllm.sparse.engine_runtime import reset_all_layer_runtimes, reset_sparse_counters
        reset_all_layer_runtimes()
        reset_sparse_counters()
        self.m12_reset()

    def sparse_set_selector(self, name: str):
        from nanovllm.sparse.engine_runtime import set_all_selectors
        set_all_selectors(name)

    def sparse_counters(self):
        from nanovllm.sparse.engine_runtime import get_sparse_counters
        c = get_sparse_counters()
        return {
            "sparse_prefill_initializations": c.sparse_prefill_initializations,
            "sparse_decode_layer_calls": c.sparse_decode_layer_calls,
            "sparse_generated_steps": c.sparse_generated_steps,
            "dense_decode_fallbacks": c.dense_decode_fallbacks,
        }

    def sparse_history_bytes(self):
        total = 0
        for m in self.model.modules():
            rt = getattr(m, "sparse_rt", None)
            if rt is not None:
                total += rt.history_bytes()
        return total

    def sparse_sample_selection(self, layer_id: int = 14):
        for m in self.model.modules():
            rt = getattr(m, "sparse_rt", None)
            if rt is not None and rt.layer_id == layer_id and rt.last_selection is not None:
                s = rt.last_selection
                return {
                    "selected_token_ratio": s.selected_token_ratio,
                    "num_selected_tokens": s.num_selected_tokens,
                    "h2d_bytes": s.h2d_bytes,
                    "full_kv_bytes": s.full_kv_bytes,
                    "truncated": s.truncated,
                    "timings_ms": {
                        "search_ms": s.search_ms,
                        "refine_ms": s.refine_ms,
                        "gather_ms": s.gather_ms,
                        "h2d_ms": s.h2d_ms,
                        "attention_ms": s.attention_ms,
                    },
                    "work": s.work,
                }
        return None

    def lookup_cpu_context(self, token_ids: list[int]):
        if self.context_db is None:
            return None
        return self.context_db.create_session(token_ids).lookup

    def restore_cpu_blocks(self, seqs: list[Sequence]) -> None:
        if self.cpu_block_store is None or self.gpu_block_store is None:
            raise RuntimeError("CPU cache is not initialized")
        before = self.cpu_block_store.stats()
        try:
            for seq in seqs:
                if not seq.cpu_restore_pending:
                    continue
                if len(seq.cpu_cache_handles) * self.block_size != seq.num_cached_tokens:
                    raise RuntimeError("CPU restore plan does not match cached-token count")
                for logical_id, handle in enumerate(seq.cpu_cache_handles):
                    gpu_block_id = seq.block_table[logical_id]
                    self.cpu_block_store.load_into(
                        handle, self.gpu_block_store.block_view(gpu_block_id)
                    )
        finally:
            after = self.cpu_block_store.stats()
            if self.metrics is not None:
                self.metrics.record_load(
                    after["load_time_ms"] - before["load_time_ms"],
                    after["h2d_bytes"] - before["h2d_bytes"],
                )

    def persist_cpu_contexts(self, seqs: list[Sequence]) -> None:
        if self.context_db is None or self.gpu_block_store is None:
            return
        before = self.cpu_block_store.stats()
        for seq in seqs:
            try:
                end = seq.num_cached_tokens + seq.num_scheduled_tokens
                if end < seq.num_prompt_tokens:
                    continue
                session = self.context_db.create_session(
                    seq.prompt_token_ids, record_stats=False
                )
                full_blocks = seq.num_prompt_tokens // self.block_size
                payloads = [
                    self.gpu_block_store.read_block(seq.block_table[logical_id])
                    for logical_id in range(session.matched_blocks, full_blocks)
                ]
                self.context_db.store_session(session, payloads)
            except Exception as exc:
                # Persistence is an optimization. A failed D2H store must not
                # fail an otherwise-correct inference request.
                self.last_cpu_store_error = repr(exc)
                if self.metrics is not None:
                    self.metrics.record_cpu_store_failure()
        after = self.cpu_block_store.stats()
        if self.metrics is not None:
            self.metrics.record_store(
                after["store_time_ms"] - before["store_time_ms"],
                after["d2h_bytes"] - before["d2h_bytes"],
                after["evictions"] - before["evictions"],
            )

    def cpu_cache_stats(self) -> dict:
        return {} if self.context_db is None else self.context_db.stats()

    def prepare_block_tables(self, seqs: list[Sequence]):
        max_len = max(len(seq.block_table) for seq in seqs)
        block_tables = [seq.block_table + [-1] * (max_len - len(seq.block_table)) for seq in seqs]
        block_tables = torch.tensor(block_tables, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        return block_tables

    def prepare_prefill(self, seqs: list[Sequence]):
        input_ids = []
        positions = []
        cu_seqlens_q = [0]
        cu_seqlens_k = [0]
        max_seqlen_q = 0
        max_seqlen_k = 0
        slot_mapping = []
        block_tables = None
        for seq in seqs:
            start = seq.num_cached_tokens
            seqlen_q = seq.num_scheduled_tokens
            end = start + seqlen_q
            seqlen_k = end
            input_ids.extend(seq[start:end])
            positions.extend(range(start, end))
            cu_seqlens_q.append(cu_seqlens_q[-1] + seqlen_q)
            cu_seqlens_k.append(cu_seqlens_k[-1] + seqlen_k)
            max_seqlen_q = max(seqlen_q, max_seqlen_q)
            max_seqlen_k = max(seqlen_k, max_seqlen_k)
            if not seq.block_table:    # warmup or sparse virtual
                continue
            start_block = start // self.block_size
            end_block = (end + self.block_size - 1) // self.block_size
            for i in range(start_block, end_block):
                slot_start = seq.block_table[i] * self.block_size
                if i == start_block:
                    slot_start += start % self.block_size
                if i != end_block - 1:
                    slot_end = seq.block_table[i] * self.block_size + self.block_size
                else:
                    slot_end = seq.block_table[i] * self.block_size + end - i * self.block_size
                slot_mapping.extend(range(slot_start, slot_end))
        if cu_seqlens_k[-1] > cu_seqlens_q[-1]:    # prefix cache
            block_tables = self.prepare_block_tables(seqs)
        input_ids = torch.tensor(input_ids, dtype=torch.int64, pin_memory=True).cuda(non_blocking=True)
        positions = torch.tensor(positions, dtype=torch.int64, pin_memory=True).cuda(non_blocking=True)
        cu_seqlens_q = torch.tensor(cu_seqlens_q, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        cu_seqlens_k = torch.tensor(cu_seqlens_k, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        slot_mapping = torch.tensor(slot_mapping, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        set_context(True, cu_seqlens_q, cu_seqlens_k, max_seqlen_q, max_seqlen_k, slot_mapping, None, block_tables)
        return input_ids, positions

    def prepare_decode(self, seqs: list[Sequence]):
        input_ids = []
        positions = []
        slot_mapping = []
        context_lens = []
        for seq in seqs:
            input_ids.append(seq.last_token)
            positions.append(len(seq) - 1)
            context_lens.append(len(seq))
            if self.config.enable_sparse_attention:
                # sparse virtual decode: no physical slot, no block table
                slot_mapping.append(-1)
            else:
                slot_mapping.append(seq.block_table[-1] * self.block_size + seq.last_block_num_tokens  - 1)
        input_ids = torch.tensor(input_ids, dtype=torch.int64, pin_memory=True).cuda(non_blocking=True)
        positions = torch.tensor(positions, dtype=torch.int64, pin_memory=True).cuda(non_blocking=True)
        slot_mapping = torch.tensor(slot_mapping, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        context_lens = torch.tensor(context_lens, dtype=torch.int32, pin_memory=True).cuda(non_blocking=True)
        block_tables = None if self.config.enable_sparse_attention else self.prepare_block_tables(seqs)
        set_context(False, slot_mapping=slot_mapping, context_lens=context_lens, block_tables=block_tables)
        return input_ids, positions

    def prepare_sample(self, seqs: list[Sequence]):
        temperatures = [seq.temperature for seq in seqs]
        temperatures = torch.tensor(temperatures, dtype=torch.float32, pin_memory=True).cuda(non_blocking=True)
        return temperatures

    @torch.inference_mode()
    def run_model(self, input_ids: torch.Tensor, positions: torch.Tensor, is_prefill: bool):
        if is_prefill or self.enforce_eager or input_ids.size(0) > 512:
            return self.model.compute_logits(self.model(input_ids, positions))
        else:
            bs = input_ids.size(0)
            context = get_context()
            graph = self.graphs[next(x for x in self.graph_bs if x >= bs)]
            graph_vars = self.graph_vars
            graph_vars["input_ids"][:bs] = input_ids
            graph_vars["positions"][:bs] = positions
            graph_vars["slot_mapping"].fill_(-1)
            graph_vars["slot_mapping"][:bs] = context.slot_mapping
            graph_vars["context_lens"].zero_()
            graph_vars["context_lens"][:bs] = context.context_lens
            graph_vars["block_tables"][:bs, :context.block_tables.size(1)] = context.block_tables
            graph.replay()
            return self.model.compute_logits(graph_vars["outputs"][:bs])

    def run(self, seqs: list[Sequence], is_prefill: bool) -> list[int]:
        input_ids, positions = self.prepare_prefill(seqs) if is_prefill else self.prepare_decode(seqs)
        temperatures = self.prepare_sample(seqs) if self.rank == 0 else None
        if self.metrics is not None and self.rank == 0:
            self.metrics.record_executed_tokens(input_ids.numel(), is_prefill=is_prefill)
        if self.metrics is None or self.rank != 0:
            logits = self.run_model(input_ids, positions, is_prefill)
        else:
            timer = ModelStageTimer(True, torch)
            with timer:
                logits = self.run_model(input_ids, positions, is_prefill)
            elapsed_ms = timer.elapsed_ms()
            if is_prefill:
                self.metrics.record_prefill(elapsed_ms)
            else:
                self.metrics.record_decode(elapsed_ms)
        token_ids = self.sampler(logits, temperatures).tolist() if self.rank == 0 else None
        reset_context()
        return token_ids

    @torch.inference_mode()
    def capture_cudagraph(self):
        config = self.config
        hf_config = config.hf_config
        max_bs = min(self.config.max_num_seqs, 512)
        max_num_blocks = (config.max_model_len + self.block_size - 1) // self.block_size
        input_ids = torch.zeros(max_bs, dtype=torch.int64)
        positions = torch.zeros(max_bs, dtype=torch.int64)
        slot_mapping = torch.zeros(max_bs, dtype=torch.int32)
        context_lens = torch.zeros(max_bs, dtype=torch.int32)
        block_tables = torch.zeros(max_bs, max_num_blocks, dtype=torch.int32)
        outputs = torch.zeros(max_bs, hf_config.hidden_size)
        self.graph_bs = [1, 2, 4, 8] + list(range(16, max_bs + 1, 16))
        self.graphs = {}
        self.graph_pool = None

        for bs in reversed(self.graph_bs):
            graph = torch.cuda.CUDAGraph()
            set_context(False, slot_mapping=slot_mapping[:bs], context_lens=context_lens[:bs], block_tables=block_tables[:bs])
            outputs[:bs] = self.model(input_ids[:bs], positions[:bs])    # warmup
            with torch.cuda.graph(graph, self.graph_pool):
                outputs[:bs] = self.model(input_ids[:bs], positions[:bs])    # capture
            if self.graph_pool is None:
                self.graph_pool = graph.pool()
            self.graphs[bs] = graph
            torch.cuda.synchronize()
            reset_context()

        self.graph_vars = dict(
            input_ids=input_ids,
            positions=positions,
            slot_mapping=slot_mapping,
            context_lens=context_lens,
            block_tables=block_tables,
            outputs=outputs,
        )
