"""M12-MVP sparse layer runtime: GPU representatives + GPU selector + CPU block gather.

One M12LayerRuntime per attention layer. The full post-RoPE history lives on
CPU in block-major layout [num_blocks, block_size, Hkv, D]. Representatives are
built on GPU from the final post-RoPE K and stay GPU-resident.  During decode
the selector runs entirely on GPU, only block IDs cross to CPU, selected blocks
are batch-gathered into a reusable pinned staging, and H2D feeds a pre-allocated
packed GPU buffer that also holds sink and recent K/V.

Chunked prefill: the 128K prompt is prefilled in chunks. The first chunk uses a
dense within-chunk FlashAttention (no history yet); every later chunk runs a
single fused exact attention over [selected historical blocks | sink | previous
recent | current chunk (causal)] so later context genuinely attends earlier
context in ONE softmax -- never independent per-chunk computation stitched
together.
"""

from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
from time import perf_counter

import torch
import torch.nn.functional as F


def prefill_recent_slice(
    valid_len: int, sink_tokens: int, recent_tokens: int,
) -> tuple[int, int, int]:
    """Return the slice of the prefill recent buffer that is not also sink.

    The prefill recent buffer is left-aligned and contains the logical suffix
    ``[max(0, valid_len - recent_tokens), valid_len)``.  Sink tokens are added
    separately, so the overlapping prefix must be omitted from the recent
    contribution.  Returns ``(buffer_start, buffer_offset, length)``.
    """
    assert valid_len >= 0
    assert sink_tokens >= 0
    assert recent_tokens >= 0

    sink_len = min(sink_tokens, valid_len)
    buffer_len = min(recent_tokens, valid_len)
    buffer_start = valid_len - buffer_len
    include_start = max(sink_len, buffer_start)
    return buffer_start, include_start - buffer_start, valid_len - include_start


def prefill_query_summaries(q: torch.Tensor, nsegments: int) -> torch.Tensor:
    """Summarize a prefill chunk into equal, locally meaningful Q segments.

    ``nsegments=1`` is bit-for-bit the historical ``q.mean(dim=0)`` route,
    represented with an explicit leading sample dimension.  For a larger value,
    each non-empty consecutive segment contributes one mean query; the selector
    takes a max score across those samples without changing the top-k block or
    H2D budget.
    """
    assert q.ndim == 3, "q must be [T, Hq, D]"
    assert nsegments > 0
    nsegments = min(nsegments, q.shape[0])
    if nsegments == 1:
        return q.mean(dim=0, keepdim=True)
    return torch.stack([part.mean(dim=0) for part in torch.tensor_split(q, nsegments)])


def dynamic_top_k_from_scores(
    top_scores: torch.Tensor, max_k: int, target_mass: float,
) -> int:
    """Choose a decode budget from half, three quarters, or all candidates.

    The scores are representative-key routing scores, not attention logits.
    Their standard deviation only removes per-layer scale; the softmax below
    is a conservative ranking heuristic and must be validated on task quality.
    Short histories and invalid/flat score lists retain every candidate.
    """
    assert top_scores.ndim == 1 and top_scores.device.type == "cpu"
    assert 0.0 < target_mass <= 1.0 and max_k > 0
    count = top_scores.numel()
    if count < max_k or count <= 1 or not bool(torch.isfinite(top_scores).all()):
        return count
    scale = top_scores.std(unbiased=False)
    if float(scale) <= 1e-6:
        return count
    weights = torch.softmax((top_scores - top_scores[0]) / scale, dim=0)
    cumulative = weights.cumsum(dim=0)
    choices = sorted({max(1, (max_k + 1) // 2),
                      max(1, (3 * max_k + 3) // 4), max_k})
    for choice in choices:
        if float(cumulative[choice - 1]) >= target_mass:
            return choice
    return max_k


@dataclass
class M12Config:
    block_size: int = 64
    r: int = 4
    recent_tokens: int = 512
    sink_tokens: int = 64
    top_k_blocks: int = 32
    prefill_top_k_blocks: int | None = None
    decode_top_k_blocks: int | None = None
    dynamic_top_k: bool = False
    dynamic_top_k_mass: float = 0.90
    max_model_len: int = 131072
    num_heads: int = 32
    num_kv_heads: int = 8
    head_dim: int = 128
    dtype: torch.dtype = torch.bfloat16
    scale: float = 128.0 ** -0.5
    use_index_select: bool = True
    decode_kv_pipeline: bool = False
    selector_cuda_graph: bool = False
    selector_static_mask: bool = False
    check_finite_outputs: bool = False
    prefill_query_segments: int = 1
    prefill_attention_backend: str = "torch"
    # Shared single-stream scratch; absent in the original/default paths.
    prefill_adapter: object | None = None

    def __post_init__(self):
        if self.decode_kv_pipeline and not self.use_index_select:
            raise ValueError("decode_kv_pipeline requires use_index_select")
        for name, budget in (
            ("prefill_top_k_blocks", self.prefill_top_k_blocks),
            ("decode_top_k_blocks", self.decode_top_k_blocks),
        ):
            if budget is not None and not 1 <= budget <= self.top_k_blocks:
                raise ValueError(f"{name} must be in [1, top_k_blocks]")


class M12LayerRuntime:
    """Per-layer GPU-representative sparse runtime."""

    def __init__(self, layer_id: int, cfg: M12Config):
        self.layer_id = layer_id
        self.cfg = cfg
        self.enabled = True

        B = cfg.block_size
        Hkv = cfg.num_kv_heads
        D = cfg.head_dim
        dtype = cfg.dtype

        self.max_blocks = (cfg.max_model_len + B - 1) // B
        self.groups_per_kv = cfg.num_heads // cfg.num_kv_heads

        # ---- CPU KV: block-major, pageable (not pinned), LAZY-allocated ----
        self.k_cpu = None
        self.v_cpu = None
        self.cpu_blocks_cap = 0
        self.nblocks_filled = 0

        # ---- GPU representatives: [Hkv, max_blocks, r, D] BF16 --------
        self.reps_gpu = torch.empty(
            Hkv, self.max_blocks, cfg.r, D, dtype=dtype, device="cuda"
        )

        # ---- GPU sink and recent windows -------------------------------
        self.sink_k = torch.zeros(cfg.sink_tokens, Hkv, D, dtype=dtype, device="cuda")
        self.sink_v = torch.zeros(cfg.sink_tokens, Hkv, D, dtype=dtype, device="cuda")
        self.recent_k = torch.zeros(cfg.recent_tokens, Hkv, D, dtype=dtype, device="cuda")
        self.recent_v = torch.zeros(cfg.recent_tokens, Hkv, D, dtype=dtype, device="cuda")

        # ---- Pre-allocated packed GPU buffer ---------------------------
        # Layout: [selected_hist | sink | recent]
        self.max_selected_tokens = cfg.top_k_blocks * B
        self.packed_total = (
            self.max_selected_tokens + cfg.sink_tokens + cfg.recent_tokens
        )
        self.packed_k = torch.empty(self.packed_total, Hkv, D, dtype=dtype, device="cuda")
        self.packed_v = torch.empty(self.packed_total, Hkv, D, dtype=dtype, device="cuda")

        # ---- Reusable pinned staging (CPU) ----------------------------
        self.stage_k = torch.empty(
            self.max_selected_tokens, Hkv, D, dtype=dtype, device="cpu", pin_memory=True
        )
        self.stage_v = torch.empty(
            self.max_selected_tokens, Hkv, D, dtype=dtype, device="cpu", pin_memory=True
        )

        # ---- State -----------------------------------------------------
        self.valid_len = 0
        self.prefill_len = 0
        self.last_block_ids: torch.Tensor | None = None
        self.protected_blocks: set[int] = set()
        self.timings: dict[str, float] = {}
        self.last_prefill_query_summaries = 0
        self.last_prefill_block_ids: torch.Tensor | None = None
        self.prefill_cpu_gather_ms = 0.0
        # Opt-in benchmark probe. Events are recorded without synchronizing;
        # the caller reads them after the enclosing engine step is synchronized.
        self.profile_cuda_stages = False
        self.cuda_stage_events: dict[str, tuple[torch.cuda.Event, torch.cuda.Event]] = {}
        # Opt-in PyTorch-profiler ranges; set by profiling benchmarks only.
        self.profile_torch_stages = False
        # Opt-in NVTX ranges for a bounded Nsight Systems capture.
        self.profile_nsys_stages = False
        # M13 diagnostic: per-decode-token selected block IDs (default off)
        self.record_ids = False
        self.ids_history: list[list[int]] = []
        self.use_index_select = cfg.use_index_select
        self._selector_graph = None
        self._selector_graph_key = None
        self._selector_graph_q = None
        self._selector_graph_outputs = None
        self._selector_graph_protected = None
        self._selector_static_mask = None
        self._selector_static_mask_key = None
        self._reps_version = 0
        self.selector_graph_setup_ms = 0.0
        self.selector_graph_builds = 0

    def _clear_selector_graph(self) -> None:
        # Each sequence/shape owns at most one graph, not an accumulating cache.
        self._selector_graph = None
        self._selector_graph_key = None
        self._selector_graph_q = None
        self._selector_graph_outputs = None
        self._selector_graph_protected = None

    def _clear_selector_static_mask(self) -> None:
        self._selector_static_mask = None
        self._selector_static_mask_key = None

    def _protected_ids_for_nblocks(self, nblocks: int) -> tuple[int, ...]:
        # Protected block IDs are nonnegative internal indices. Ignore IDs
        # beyond the currently filled history, just like the legacy selector.
        return tuple(sorted(p for p in self.protected_blocks if 0 <= p < nblocks))

    def _get_selector_static_mask(self, protected_ids: tuple[int, ...], device):
        if not protected_ids:
            self._clear_selector_static_mask()
            return None
        key = (protected_ids, torch.device(device))
        if key != self._selector_static_mask_key:
            self._selector_static_mask = torch.tensor(
                protected_ids, dtype=torch.long, device=device)
            self._selector_static_mask_key = key
        return self._selector_static_mask

    def reset(self) -> None:
        """Start a new sequence without reallocating the large KV buffers.

        Every subsequent read is bounded by these logical lengths. The first
        prefill chunk overwrites the used CPU KV/reps and sink/recent windows.
        """
        self.nblocks_filled = 0
        self.valid_len = 0
        self.prefill_len = 0
        self.last_block_ids = None
        self.protected_blocks.clear()
        self.timings.clear()
        self.last_prefill_query_summaries = 0
        self.last_prefill_block_ids = None
        self.prefill_cpu_gather_ms = 0.0
        self.cuda_stage_events.clear()
        self.ids_history.clear()
        self._clear_selector_graph()
        self._clear_selector_static_mask()
        self.selector_graph_setup_ms = 0.0
        self.selector_graph_builds = 0

    # ------------------------------------------------------------------
    # Representative construction on GPU (batched over blocks and heads)
    # ------------------------------------------------------------------
    def _build_reps_gpu(self, k_blocks: torch.Tensor, start: int, nblocks: int):
        """Build r real-key representatives on GPU per (block, kv_head).

        k_blocks: [nblocks, block_size, Hkv, D] BF16, post-RoPE real K.
        Writes self.reps_gpu[:, start:start+nblocks, :, :].
        mean-direction real key + farthest-point directional coverage;
        normalization is used ONLY for selection; stored reps are raw real K.
        """
        self._clear_selector_graph()
        self._reps_version += 1
        cfg = self.cfg
        B, Hkv, D, r = cfg.block_size, cfg.num_kv_heads, cfg.head_dim, cfg.r
        N = nblocks
        dev = k_blocks.device

        K = k_blocks[:N].to(torch.float32)          # [N, B, H, D]
        K_dir = F.normalize(K, dim=-1)              # [N, B, H, D]
        Kt = K.permute(0, 2, 1, 3)                  # [N, H, B, D]
        Kdt = K_dir.permute(0, 2, 1, 3)             # [N, H, B, D]

        mean_dir = F.normalize(K_dir.mean(dim=1), dim=-1)   # [N, H, D]
        cos0 = torch.einsum("nbhd,nhd->nbh", K_dir, mean_dir)  # [N, B, H]
        sel_idx = torch.empty(N, Hkv, r, dtype=torch.long, device=dev)
        sel_idx[:, :, 0] = cos0.argmax(dim=1)        # [N, H]

        INF = 2.0
        for step in range(1, r):
            idx = sel_idx[:, :, :step]               # [N, H, step]
            sel_dirs = torch.gather(
                Kdt, 2, idx.unsqueeze(-1).expand(N, Hkv, step, D))
            cos_sim = torch.einsum("nbhd,nhsd->nbhs", K_dir, sel_dirs)  # [N,B,H,step]
            max_cos = cos_sim.amax(dim=-1)           # [N, B, H]
            with torch.no_grad():
                mask = torch.zeros(N, B, Hkv, device=dev)
                mask.scatter_(1, idx.permute(0, 2, 1).reshape(N, step, Hkv), INF)
            max_cos = torch.maximum(max_cos, mask)
            sel_idx[:, :, step] = max_cos.argmin(dim=1)   # [N, H]

        raw = torch.gather(
            Kt, 2, sel_idx.unsqueeze(-1).expand(N, Hkv, r, D))
        self.reps_gpu[:, start:start + N, :, :] = (
            raw.permute(1, 0, 2, 3).to(self.reps_gpu.dtype))

    # ------------------------------------------------------------------
    # One-shot CPU KV reservation (avoid lazy-growth peak at 128K)
    # ------------------------------------------------------------------
    def reserve_blocks(self, nblocks: int):
        """Preallocate pageable CPU KV for nblocks blocks (no copy)."""
        cfg = self.cfg
        need = min(nblocks, self.max_blocks)
        if self.k_cpu is None or self.cpu_blocks_cap < need:
            self.k_cpu = torch.empty(
                need, cfg.block_size, cfg.num_kv_heads, cfg.head_dim,
                dtype=cfg.dtype, device="cpu")
            self.v_cpu = torch.empty(
                need, cfg.block_size, cfg.num_kv_heads, cfg.head_dim,
                dtype=cfg.dtype, device="cpu")
            self.cpu_blocks_cap = need

    # ------------------------------------------------------------------
    # Store K/V to CPU + build reps + refresh sink/recent/protected
    # ------------------------------------------------------------------
    def _store_kv(self, k: torch.Tensor, v: torch.Tensor):
        """Append a prefill chunk's post-RoPE K/V to the CPU history.

        k,v: [T, Hkv, D] GPU tensors.
        """
        cfg = self.cfg
        B = cfg.block_size
        T, Hkv, D = k.shape
        assert T >= 2

        padded = ((T + B - 1) // B) * B
        if padded > T:
            k_pad = F.pad(k, (0, 0, 0, 0, 0, padded - T))
            v_pad = F.pad(v, (0, 0, 0, 0, 0, padded - T))
        else:
            k_pad, v_pad = k, v

        start_block = self.nblocks_filled
        nblocks = padded // B
        k_blocks = k_pad.view(nblocks, B, Hkv, D)
        v_blocks = v_pad.view(nblocks, B, Hkv, D)

        # Lazily grow pageable CPU KV (never pinned).
        need = start_block + nblocks
        if self.k_cpu is None or self.cpu_blocks_cap < need:
            new_cap = max(need, 2 * (self.cpu_blocks_cap or 1))
            new_k = torch.empty(new_cap, B, Hkv, D, dtype=cfg.dtype, device="cpu")
            new_v = torch.empty(new_cap, B, Hkv, D, dtype=cfg.dtype, device="cpu")
            if self.k_cpu is not None and start_block > 0:
                new_k[:start_block].copy_(self.k_cpu[:start_block])
                new_v[:start_block].copy_(self.v_cpu[:start_block])
            self.k_cpu, self.v_cpu = new_k, new_v
            self.cpu_blocks_cap = new_cap

        self.k_cpu[start_block:need].copy_(k_blocks.cpu())
        self.v_cpu[start_block:need].copy_(v_blocks.cpu())

        # Build reps for the new blocks on GPU.
        self._build_reps_gpu(k_blocks, start_block, nblocks)

        # Sink: earliest tokens (first chunk only).
        if self.prefill_len == 0:
            sink_len = min(cfg.sink_tokens, T)
            self.sink_k[:sink_len].copy_(k[:sink_len])
            self.sink_v[:sink_len].copy_(v[:sink_len])

        # Recent: tail of everything seen so far.
        recent_len = min(cfg.recent_tokens, self.valid_len + T)
        if T >= recent_len:
            self.recent_k[:recent_len].copy_(k[-recent_len:])
            self.recent_v[:recent_len].copy_(v[-recent_len:])
        else:
            carry = recent_len - T
            old_recent_len = min(cfg.recent_tokens, self.valid_len)
            # The old window is left-aligned and may be shorter than the new
            # one. Snapshot its suffix before shifting overlapping slices.
            self.recent_k[:carry].copy_(
                self.recent_k[old_recent_len - carry:old_recent_len].clone())
            self.recent_v[:carry].copy_(
                self.recent_v[old_recent_len - carry:old_recent_len].clone())
            self.recent_k[carry:recent_len].copy_(k)
            self.recent_v[carry:recent_len].copy_(v)

        self.valid_len += T
        self.prefill_len += T
        self.nblocks_filled = need

        # Historical blocks exclude sink (block 0) and recent (tail blocks).
        n_recent_blocks = cfg.recent_tokens // B
        sink_blocks = {0}
        recent_blocks = set(range(max(1, need - n_recent_blocks), need))
        self.protected_blocks = sink_blocks | recent_blocks

    # ------------------------------------------------------------------
    # First prefill chunk: dense within-chunk attention (no history yet)
    # ------------------------------------------------------------------
    def prefill_first(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> dict:
        """Store the first chunk; dense attention is done by the caller (FA2)."""
        assert self.prefill_len == 0, "prefill_first called after history exists"
        with self._profile_range("prefill_first_store_kv"):
            self._store_kv(k, v)
        return {"nblocks": self.nblocks_filled, "valid_len": self.valid_len}

    # ------------------------------------------------------------------
    # Later prefill chunk: fused exact attention over history+sink+recent+chunk
    # ------------------------------------------------------------------
    def prefill_chunk(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
                      device: torch.device) -> torch.Tensor:
        """Fused exact attention for a later prefill chunk.

        q,k,v: [T, Hq/Hkv, D] GPU, post-RoPE.
        Attention attends [top-k historical blocks | sink | previous recent |
        current chunk (causal)] in ONE softmax (never independent per-chunk
        stitching).  Selected history excludes sink/recent protected blocks, so
        this packed layout covers each represented history token exactly once.
        """
        cfg = self.cfg
        B = cfg.block_size
        T, Hkv, D = k.shape
        Hq = cfg.num_heads
        assert self.prefill_len > 0, "prefill_chunk requires prior history"

        # 1. Select historical blocks from one or more local query summaries.
        # Four segment means preserve intent that a 4096-token global mean
        # would otherwise cancel, while leaving the block/H2D budget unchanged.
        with self._profile_range("prefill_selector"):
            q_summary = prefill_query_summaries(q, cfg.prefill_query_segments)
            self.last_prefill_query_summaries = q_summary.shape[0]
            if cfg.prefill_top_k_blocks is None:
                hist_ids, sel_info = self._gpu_select(q_summary)  # [K] CPU
            else:
                hist_ids, sel_info = self._gpu_select(
                    q_summary, budget=cfg.prefill_top_k_blocks)  # [K] CPU

        # 2. CPU batch gather selected historical blocks into pinned staging.
        Ksel = hist_ids.shape[0]
        sel_hist_tokens = Ksel * B
        t_gather = perf_counter()
        with self._profile_range("prefill_cpu_gather"):
            if self.use_index_select:
                flat_k = self.k_cpu[:self.cpu_blocks_cap].view(-1, Hkv, D)
                flat_v = self.v_cpu[:self.cpu_blocks_cap].view(-1, Hkv, D)
                tok_idx = (hist_ids.view(-1, 1) * B
                           + torch.arange(B, dtype=torch.long)).reshape(-1)
                torch.index_select(flat_k, 0, tok_idx, out=self.stage_k[:sel_hist_tokens])
                torch.index_select(flat_v, 0, tok_idx, out=self.stage_v[:sel_hist_tokens])
            else:
                sel_k = self.k_cpu[hist_ids].reshape(sel_hist_tokens, Hkv, D)
                sel_v = self.v_cpu[hist_ids].reshape(sel_hist_tokens, Hkv, D)
                self.stage_k[:sel_hist_tokens].copy_(sel_k)
                self.stage_v[:sel_hist_tokens].copy_(sel_v)
        self.prefill_cpu_gather_ms += (perf_counter() - t_gather) * 1000.0

        # 3. Fused packed exact attention.  The current chunk must not update
        # recent before this pack is assembled: selector protection excluded the
        # *previous* recent blocks, so they have to be explicitly restored here.
        with self._profile_range("prefill_h2d_pack"):
            sink_len = min(cfg.sink_tokens, self.valid_len)
            _, recent_offset, recent_len = prefill_recent_slice(
                self.valid_len, cfg.sink_tokens, cfg.recent_tokens)
            adapter = cfg.prefill_adapter
            if adapter is not None:
                recent_end = recent_offset + recent_len
                invocation = adapter.prepare(
                    q, self.stage_k[:sel_hist_tokens], self.stage_v[:sel_hist_tokens],
                    (self.sink_k[:sink_len], self.sink_v[:sink_len]),
                    (self.recent_k[recent_offset:recent_end], self.recent_v[recent_offset:recent_end]),
                    (k, v))
            else:
                total = sel_hist_tokens + sink_len + recent_len + T
                k_pack = torch.empty(total, Hkv, D, dtype=k.dtype, device=device)
                v_pack = torch.empty(total, Hkv, D, dtype=k.dtype, device=device)

                off = 0
                k_pack[off:off + sel_hist_tokens] = self.stage_k[:sel_hist_tokens].to(device)
                v_pack[off:off + sel_hist_tokens] = self.stage_v[:sel_hist_tokens].to(device)
                off += sel_hist_tokens
                k_pack[off:off + sink_len] = self.sink_k[:sink_len]
                v_pack[off:off + sink_len] = self.sink_v[:sink_len]
                off += sink_len

                if recent_len:
                    recent_end = recent_offset + recent_len
                    k_pack[off:off + recent_len] = self.recent_k[recent_offset:recent_end]
                    v_pack[off:off + recent_len] = self.recent_v[recent_offset:recent_end]
                    off += recent_len

                k_pack[off:off + T] = k
                v_pack[off:off + T] = v

        with self._profile_range("prefill_attention"):
            if adapter is not None:
                o = adapter.attend(invocation)
            else:
                o = self._prefill_attention(q, k_pack, v_pack, causal_from=off)

        # Current K/V become history only after current-chunk attention has
        # consumed the previous recent window.  This order avoids the old gap
        # where protected recent blocks were neither selected nor packed.
        with self._profile_range("prefill_store_kv"):
            self._store_kv(k, v)
        self.last_prefill_block_ids = hist_ids.clone()
        self.last_block_ids = hist_ids
        return o

    def _prefill_attention(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        causal_from: int,
    ) -> torch.Tensor:
        """Run later-chunk packed attention with a selectable exact backend.

        FlashAttention 2's bottom-right causal alignment for ``Sq < Sk`` gives
        every query access to the full historical prefix and to current-chunk
        keys through its own position.  That is the same mask constructed by
        ``_fused_attention``; the latter remains the small, inspectable
        reference backend for parity tests and diagnosis.
        """
        if self.cfg.prefill_attention_backend == "torch":
            return self._fused_attention(
                q, k, v, hist_len=causal_from, sink_len=0,
                causal_from=causal_from,
            )
        if self.cfg.prefill_attention_backend != "flash":
            raise ValueError(
                f"unknown prefill attention backend: "
                f"{self.cfg.prefill_attention_backend!r}")

        from flash_attn import flash_attn_func

        return flash_attn_func(
            q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0),
            softmax_scale=self.cfg.scale, causal=True,
        ).squeeze(0)

    # ------------------------------------------------------------------
    # Fused exact attention (decode or prefill-chunk), per-KV-head loop to
    # keep peak GPU memory bounded.
    # ------------------------------------------------------------------
    def _fused_attention(
        self,
        q: torch.Tensor,          # [Tq, Hq, D] GPU
        k: torch.Tensor,          # [S, Hkv, D] GPU
        v: torch.Tensor,          # [S, Hkv, D] GPU
        hist_len: int,
        sink_len: int,
        causal_from: int,         # start index of the causal (current-chunk) region
    ) -> torch.Tensor:
        cfg = self.cfg
        Tq = q.shape[0]
        S = k.shape[0]
        Hq = cfg.num_heads
        Hkv = cfg.num_kv_heads
        D = cfg.head_dim
        G = Hq // Hkv

        q_f = q.float()                     # [Tq, Hq, D]
        k_f = k.float()                     # [S, Hkv, D]
        v_f = v.float()

        # Decode / no-causal fast path: batch all KV heads in one op (no mask).
        if causal_from >= S:
            qg = q_f.view(Tq, Hkv, G, D)                        # [Tq,Hkv,G,D]
            scores = torch.einsum("thgd,shd->thgs", qg, k_f) * cfg.scale  # [Tq,Hkv,G,S]
            attn = F.softmax(scores, dim=-1)
            out = torch.einsum("thgs,shd->thgd", attn, v_f)     # [Tq,Hkv,G,D]
            return out.reshape(Tq, Hq, D).to(q.dtype)

        # causal mask for the chunk region: per-query-row [Tq, S]
        # query t (chunk-relative position t) sees history + chunk keys <= t
        mask = torch.zeros(Tq, S, dtype=torch.bool, device=q.device)
        if causal_from < S:
            cols = torch.arange(S, device=q.device).unsqueeze(0)      # [1, S]
            rows = (torch.arange(Tq, device=q.device) + causal_from + 1).unsqueeze(1)  # [Tq,1]
            mask = (cols >= rows) & (cols >= causal_from)             # [Tq, S]

        qg = q_f.view(Tq, Hkv, G, D)        # [Tq, Hkv, G, D]
        out = torch.empty(Tq, Hq, D, dtype=q_f.dtype, device=q.device)
        for h in range(Hkv):
            qh = qg[:, h]                   # [Tq, G, D]
            kh = k_f[:, h, :]               # [S, D]
            vh = v_f[:, h, :]               # [S, D]
            # scores: [Tq, G, S]
            scores = torch.einsum("tgd,sd->tgs", qh, kh) * cfg.scale
            scores = scores.masked_fill(mask.unsqueeze(1), float("-inf"))  # [Tq,G,S]
            attn = F.softmax(scores, dim=-1)
            o = torch.einsum("tgs,sd->tgd", attn, vh)   # [Tq, G, D]
            out[:, h * G:(h + 1) * G, :] = o
        return out.to(q.dtype)

    # ------------------------------------------------------------------
    # GPU selector (fully vectorized)
    # ------------------------------------------------------------------
    def _selector_graph_ops(self, q: torch.Tensor, nblocks: int, k: int,
                            protected: torch.Tensor):
        """Original FP32 scoring/reduction order, with graph-safe static IDs."""
        cfg = self.cfg
        q_g = q.view(q.shape[0], cfg.num_kv_heads, self.groups_per_kv, cfg.head_dim)
        scores = torch.einsum(
            "nhgd,hbrd->nhgbr", q_g.float(), self.reps_gpu[:, :nblocks].float())
        scores = scores.amax(dim=-1).amax(dim=2).amax(dim=0)
        global_scores = scores.amax(dim=0)
        if protected.numel():
            # Scalar advanced assignment may copy a host scalar to CUDA and
            # synchronize. index_fill_ passes the scalar directly to a kernel.
            global_scores.index_fill_(0, protected, float("-inf"))
        return global_scores.topk(k)

    def _graph_select(self, q: torch.Tensor, nblocks: int, k: int):
        # Filter on CPU: a CUDA boolean-indexed result has a data-dependent
        # shape and can synchronize, making it unsafe to capture.
        protected_ids = tuple(sorted(p for p in self.protected_blocks if p < nblocks))
        key = (nblocks, k, protected_ids, tuple(q.shape), q.dtype, q.device,
               self.reps_gpu.data_ptr(), self._reps_version)
        if key != self._selector_graph_key:
            self._clear_selector_graph()
            started = perf_counter()
            static_q = torch.empty_like(q)
            static_q.copy_(q)
            protected = torch.tensor(protected_ids, dtype=torch.long, device=q.device)
            stream = torch.cuda.Stream(device=q.device)
            stream.wait_stream(torch.cuda.current_stream(q.device))
            with torch.cuda.stream(stream):
                for _ in range(3):
                    warm_outputs = self._selector_graph_ops(static_q, nblocks, k, protected)
            torch.cuda.current_stream(q.device).wait_stream(stream)
            del warm_outputs
            graph = torch.cuda.CUDAGraph()
            # torch.cuda.graph's convenience context globally synchronizes,
            # runs Python GC, and empties the allocator cache on EACH entry.
            # There are 36 per-layer graphs here. Warm and finish the capture
            # stream explicitly, then use raw capture without repeated GC.
            # Sparse M12 is single-sequence, TP=1, eager: no concurrent capture.
            with torch.cuda.stream(stream):
                stream.synchronize()
                graph.capture_begin()
                try:
                    outputs = self._selector_graph_ops(static_q, nblocks, k, protected)
                finally:
                    graph.capture_end()
            self._selector_graph_q = static_q
            self._selector_graph_protected = protected
            self._selector_graph_outputs = outputs
            self._selector_graph = graph
            self._selector_graph_key = key
            self.selector_graph_setup_ms += (perf_counter() - started) * 1000.0
            self.selector_graph_builds += 1
        self._selector_graph_q.copy_(q)
        self._selector_graph.replay()
        return self._selector_graph_outputs

    def _gpu_select(self, q: torch.Tensor, *, dynamic: bool = False,
                    budget: int | None = None, use_graph: bool = False,
                    use_static_mask: bool = False
                    ) -> tuple[torch.Tensor, dict]:
        """GPU-vectorized GQA group-score + global temporal top-k.

        q: [Hq, D] or [Nq, Hq, D] GPU post-RoPE query summaries.  The Nq
           dimension is used by multi-query prefill routing and is max-reduced.
        Returns (block_ids_cpu [K] int64, timing_dict).
        """
        cfg = self.cfg
        Hq, Hkv, D = cfg.num_heads, cfg.num_kv_heads, cfg.head_dim
        nblocks = self.nblocks_filled

        if q.ndim == 2:
            q = q.unsqueeze(0)
        assert q.ndim == 3 and q.shape[1:] == (Hq, D)
        nq = q.shape[0]
        static_mask = use_static_mask and not (use_graph and cfg.selector_cuda_graph)
        protected_ids = (self._protected_ids_for_nblocks(nblocks)
                         if static_mask else None)
        n_prot = (len(protected_ids) if static_mask else
                  len([p for p in self.protected_blocks if p < nblocks]))
        avail = nblocks - n_prot
        requested_k = cfg.top_k_blocks if budget is None else budget
        k = min(requested_k, max(1, avail))
        if use_graph and cfg.selector_cuda_graph:
            topk_scores, topk_ids = self._graph_select(q, nblocks, k)
        else:
            q_g = q.view(nq, Hkv, self.groups_per_kv, D)
            scores = torch.einsum(
                "nhgd,hbrd->nhgbr", q_g.float(), self.reps_gpu[:, :nblocks].float())
            scores = scores.amax(dim=-1).amax(dim=2).amax(dim=0)
            global_scores = scores.amax(dim=0)
            if static_mask:
                protected = self._get_selector_static_mask(
                    protected_ids, global_scores.device)
                if protected is not None:
                    global_scores.index_fill_(0, protected, float("-inf"))
            elif self.protected_blocks:
                prot = torch.tensor(sorted(self.protected_blocks),
                                    dtype=torch.long, device=global_scores.device)
                prot = prot[prot < nblocks]
                if prot.numel() > 0:
                    global_scores[prot] = float("-inf")
            topk_scores, topk_ids = global_scores.topk(k)

        t_d2h = perf_counter()
        with self._profile_range("selector_id_d2h"):
            if dynamic and cfg.dynamic_top_k and k == requested_k:
                topk_scores_cpu = topk_scores.cpu()
                chosen = dynamic_top_k_from_scores(
                    topk_scores_cpu, requested_k, cfg.dynamic_top_k_mass)
            else:
                chosen = k
            block_ids_cpu = topk_ids.cpu()
            if chosen < k:
                block_ids_cpu = block_ids_cpu[:chosen]
        d2h_ms = (perf_counter() - t_d2h) * 1000.0

        return block_ids_cpu, {
            "d2h_ms": d2h_ms,
            "n_selected": chosen,
            "n_candidates": k,
            "n_query_summaries": nq,
        }

    def _profile_range(self, name: str):
        """Return a named profiler range when explicitly enabled."""
        if self.profile_torch_stages:
            return torch.profiler.record_function(f"m12.{name}")
        if self.profile_nsys_stages:
            return torch.cuda.nvtx.range(f"m12.{name}.layer{self.layer_id}")
        return nullcontext()

    # ------------------------------------------------------------------
    # Decode
    # ------------------------------------------------------------------
    def decode(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
               device: torch.device) -> torch.Tensor:
        """One decode step. q/k/v: [1, Hq/Hkv, D] GPU post-RoPE."""
        cfg = self.cfg
        B = cfg.block_size
        Hkv = cfg.num_kv_heads
        D = cfg.head_dim
        Hq = cfg.num_heads

        assert q.shape[0] == 1 and k.shape[0] == 1

        def event_pair(name: str):
            if not self.profile_cuda_stages:
                return None
            pair = (torch.cuda.Event(enable_timing=True),
                    torch.cuda.Event(enable_timing=True))
            self.cuda_stage_events[name] = pair
            pair[0].record()
            return pair

        # 1. Append current token to recent window (shift left; clone avoids
        #    overlapping-copy error, buffer itself is reused)
        recent_events = event_pair("recent")
        t0 = perf_counter()
        with self._profile_range("recent_update"):
            self.recent_k[:-1].copy_(self.recent_k[1:].clone())
            self.recent_v[:-1].copy_(self.recent_v[1:].clone())
            self.recent_k[-1].copy_(k[0])
            self.recent_v[-1].copy_(v[0])
        recent_ms = (perf_counter() - t0) * 1000.0
        if recent_events:
            recent_events[1].record()

        # 2. GPU selector -> block IDs D2H
        selector_events = event_pair("selector")
        t_sel = perf_counter()
        with self._profile_range("selector"):
            block_ids_cpu, sel_info = self._gpu_select(
                q[0], dynamic=cfg.dynamic_top_k,
                budget=cfg.decode_top_k_blocks, use_graph=cfg.selector_cuda_graph,
                use_static_mask=cfg.selector_static_mask)
        selector_ms = (perf_counter() - t_sel) * 1000.0
        if selector_events:
            selector_events[1].record()

        if self.record_ids:
            self.ids_history.append(block_ids_cpu.tolist())

        K = block_ids_cpu.shape[0]
        sel_hist_tokens = K * B

        # 3. CPU batch gather into pinned staging (vectorized index, no per-block loop)
        t_g = perf_counter()
        with self._profile_range("cpu_gather"):
            if self.use_index_select:
                flat_k = self.k_cpu[:self.cpu_blocks_cap].view(-1, Hkv, D)
                flat_v = self.v_cpu[:self.cpu_blocks_cap].view(-1, Hkv, D)
                tok_idx = (block_ids_cpu.view(-1, 1) * B
                           + torch.arange(B, dtype=torch.long)).reshape(-1)
                torch.index_select(flat_k, 0, tok_idx, out=self.stage_k[:sel_hist_tokens])
                if not cfg.decode_kv_pipeline:
                    torch.index_select(flat_v, 0, tok_idx, out=self.stage_v[:sel_hist_tokens])
            else:
                sel_k = self.k_cpu[block_ids_cpu].reshape(sel_hist_tokens, Hkv, D)
                sel_v = self.v_cpu[block_ids_cpu].reshape(sel_hist_tokens, Hkv, D)
                self.stage_k[:sel_hist_tokens].copy_(sel_k)
                self.stage_v[:sel_hist_tokens].copy_(sel_v)
        gather_ms = (perf_counter() - t_g) * 1000.0

        # 4. Assemble packed GPU buffer: [selected_hist | sink | recent]
        h2d_events = event_pair("h2d_pack")
        t_h = perf_counter()
        with self._profile_range("h2d_pack"):
            self.packed_k[:sel_hist_tokens].copy_(
                self.stage_k[:sel_hist_tokens], non_blocking=True)
        h2d_ms = (perf_counter() - t_h) * 1000.0
        if cfg.decode_kv_pipeline:
            # K DMA may progress while the CPU fills a DISTINCT V staging
            # buffer. No host slice is overwritten before its copy completes.
            # All GPU work stays on the current stream: V and attention remain
            # ordered after K, without an extra stream or CUDA synchronization.
            t_gv = perf_counter()
            with self._profile_range("cpu_gather"):
                torch.index_select(flat_v, 0, tok_idx, out=self.stage_v[:sel_hist_tokens])
            gather_ms += (perf_counter() - t_gv) * 1000.0
        t_h = perf_counter()
        with self._profile_range("h2d_pack"):
            self.packed_v[:sel_hist_tokens].copy_(
                self.stage_v[:sel_hist_tokens], non_blocking=True)
            off = sel_hist_tokens

            sink_len = min(cfg.sink_tokens, self.valid_len)
            self.packed_k[off:off + sink_len].copy_(self.sink_k[:sink_len])
            self.packed_v[off:off + sink_len].copy_(self.sink_v[:sink_len])
            off += sink_len

            recent_len = min(cfg.recent_tokens, self.valid_len + 1)
            self.packed_k[off:off + recent_len].copy_(self.recent_k[-recent_len:])
            self.packed_v[off:off + recent_len].copy_(self.recent_v[-recent_len:])
            off += recent_len
        total_attend = off
        h2d_ms += (perf_counter() - t_h) * 1000.0
        if h2d_events:
            h2d_events[1].record()

        # 5. Packed exact attention over [hist | sink | recent]
        attention_events = event_pair("packed_attention")
        t_a = perf_counter()
        with self._profile_range("packed_attention"):
            o = self._fused_attention(
                q, self.packed_k[:total_attend], self.packed_v[:total_attend],
                hist_len=sel_hist_tokens, sink_len=sink_len, causal_from=total_attend,
            )
        attn_ms = (perf_counter() - t_a) * 1000.0
        if attention_events:
            attention_events[1].record()

        self.valid_len += 1
        self.last_block_ids = block_ids_cpu

        self.timings = {
            "selector_ms": selector_ms,
            "d2h_ms": sel_info.get("d2h_ms", 0.0),
            "cpu_gather_ms": gather_ms,
            "h2d_pack_ms": h2d_ms,
            # CUDA events span the pipeline's CPU V gather too; they are not
            # an exclusive device-memcpy measurement in this mode.
            "h2d_event_spans_cpu_gather": cfg.decode_kv_pipeline,
            "recent_ms": recent_ms,
            "packed_attn_ms": attn_ms,
            "selected_tokens": sel_hist_tokens,
            "total_attend_tokens": total_attend,
        }

        if cfg.check_finite_outputs and not bool(torch.isfinite(o).all()):
            raise RuntimeError("M12 sparse decode output is non-finite")

        return o
